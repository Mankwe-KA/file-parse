package com.eviro.assessment.grad001.kgothatsomankwe;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileParserApplication {

	public static void main(String[] args) {


		SpringApplication.run(FileParserApplication.class, args);
	}


	 
}
