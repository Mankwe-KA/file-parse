package com.eviro.assessment.grad001.kgothatsomankwe.service;
import com.eviro.assessment.grad001.kgothatsomankwe.model.AccountProfile;
import com.eviro.assessment.grad001.kgothatsomankwe.parser.FileParser;
import com.eviro.assessment.grad001.kgothatsomankwe.repository.AccountProfileRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

@Service
public class AccountProfileService {

    private final AccountProfileRepository accountProfileRepository;
    private final FileParser fileParser;

    public AccountProfileService(AccountProfileRepository accountProfileRepository, FileParser fileParser) {
        this.accountProfileRepository = accountProfileRepository;
        this.fileParser = fileParser;
    }

    public void processCSVFile(MultipartFile csvFile, String base64ImageData) {
        File tempCsvFile;
        try {
            tempCsvFile = File.createTempFile("temp", ".csv");
            csvFile.transferTo(tempCsvFile);
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        fileParser.parseCSV(tempCsvFile);

        File imageFile = fileParser.convertCSVDataToImage(base64ImageData);
        if (imageFile != null) {
            AccountProfile accountProfile = new AccountProfile();
            // Set account holder name and surname from parsed CSV

            accountProfile.setHttpImageLink(fileParser.createImageLink(imageFile).toString());

            accountProfileRepository.save(accountProfile);
        }

        // Delete temporary files if necessary
        tempCsvFile.delete();
        imageFile.delete();
    }
}
