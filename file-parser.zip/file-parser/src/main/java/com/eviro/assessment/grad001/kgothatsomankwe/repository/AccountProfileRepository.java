package com.eviro.assessment.grad001.kgothatsomankwe.repository;
import com.eviro.assessment.grad001.kgothatsomankwe.model.AccountProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountProfileRepository extends JpaRepository<AccountProfile, Long> {
}
