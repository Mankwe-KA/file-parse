package com.eviro.assessment.grad001.kgothatsoandmankwe.fileparser;
import com.eviro.assessment.grad001.kgothatsomankwe.FileParserApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = FileParserApplication.class)
class FileParserApplicationTests {

	@Test
	void contextLoads() {
	}

}
