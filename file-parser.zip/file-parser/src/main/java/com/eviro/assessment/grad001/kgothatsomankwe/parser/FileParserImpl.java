package com.eviro.assessment.grad001.kgothatsomankwe.parser;
import com.eviro.assessment.grad001.kgothatsomankwe.model.AccountProfile;
import com.eviro.assessment.grad001.kgothatsomankwe.repository.AccountProfileRepository;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Base64;

public class FileParserImpl implements FileParser {

    private static final String IMAGE_OUTPUT_DIR = "image-output/";
    private static final String CSV_FILE_LOCATION = "src/main/resources/data/your_csv.csv";

    private final AccountProfileRepository accountProfileRepository;

    public FileParserImpl(AccountProfileRepository accountProfileRepository) {
        this.accountProfileRepository = accountProfileRepository;
    }

    @Override
    public void parseCSV(File csvFile) {
        try (CSVReader csvReader = new CSVReader(new FileReader(csvFile))) {
            String[] line;
            while ((line = csvReader.readNext()) != null) {
                // Extract the necessary values from the line and process them
                String accountHolderName = line[0];
                String accountHolderSurname = line[1];

                // Perform any required operations with the extracted values
                // For example, you can create an AccountProfile object and save it to the database
                AccountProfile accountProfile = new AccountProfile();
                accountProfile.setAccountHolderName(accountHolderName);
                accountProfile.setAccountHolderSurname(accountHolderSurname);
                accountProfileRepository.save(accountProfile);
            }
        } catch (IOException | CsvValidationException e) {
            e.printStackTrace();
        }
    }

    public void loadCSVFile() {
        File csvFile = new File(CSV_FILE_LOCATION);
        parseCSV(csvFile);
    }

    @Override
    public File convertCSVDataToImage(String base64ImageData) {
        try {
            byte[] imageBytes = Base64.getDecoder().decode(base64ImageData);
            File imageFile = new File(IMAGE_OUTPUT_DIR + "output-image.jpg");
            FileOutputStream fileOutputStream = new FileOutputStream(imageFile);
            fileOutputStream.write(imageBytes);
            fileOutputStream.close();
            return imageFile;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public URI createImageLink(File fileImage) {
        try {
            Path imagePath = fileImage.toPath();
            Path targetPath = Path.of(IMAGE_OUTPUT_DIR + fileImage.getName());
            Files.move(imagePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
            return targetPath.toUri();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
