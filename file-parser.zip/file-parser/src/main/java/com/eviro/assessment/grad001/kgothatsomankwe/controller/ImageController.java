package com.eviro.assessment.grad001.kgothatsomankwe.controller;
import com.eviro.assessment.grad001.kgothatsomankwe.model.AccountProfile;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.RequestMapping;

import com.eviro.assessment.grad001.kgothatsomankwe.service.AccountProfileService;

@RestController
@RequestMapping("/v1/api/image")
public class ImageController {

    private final AccountProfileService accountProfileService;

    public ImageController(AccountProfileService accountProfileService) {
        this.accountProfileService = accountProfileService;
    }

    @GetMapping("/{name}/{surname}")
    public List<AccountProfile> getAccountProfilesByNameAndSurname(
            @PathVariable String name,
            @PathVariable String surname) {
        // Implement fetching account profiles by name and surname
        return null;
    }

    @PostMapping("/{name}/{surname}")
    @ResponseStatus(HttpStatus.CREATED)
    public void uploadImage(
            @PathVariable String name,
            @PathVariable String surname,
            @RequestParam("csvFile") MultipartFile csvFile,
            @RequestParam("image") String base64ImageData) {
        accountProfileService.processCSVFile(csvFile, base64ImageData);
    }

    @GetMapping("/{name}/{surname}/{filename:.+}")
    public FileSystemResource getHttpImageLink(
            @PathVariable String name,
            @PathVariable String surname,
            @PathVariable String filename) {
        // Implement fetching the physical image file
        return null;
    }
}
